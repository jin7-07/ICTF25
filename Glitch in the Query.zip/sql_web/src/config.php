<?php
session_start();

// Block sqlmap
if (isset($_SERVER['HTTP_USER_AGENT']) && strpos($_SERVER['HTTP_USER_AGENT'], 'sqlmap') !== false) {
    die("Access denied: sqlmap detected.");
}

$servername = "db";
$username = "player";
$password = "playerpass";
$dbname = "ctf_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
