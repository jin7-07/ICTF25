<?php
function check_waf($cmd) {
    $blacklist = ['cat', 'sqlmap', 'wget', 'curl', 'nc', 'bash', 'sh', '&', '|', ';', '>', '<'];
    foreach ($blacklist as $bad) {
        if (stripos($cmd, $bad) !== false) {
            return true;
        }
    }
    return false;
}
?>
