<?php
include "config.php";

// Handle SQL Injection Query
if (isset($_GET['query'])) {
    $query = $_GET['query']; // Vulnerable SQL input
    
    try {
        $result = $conn->query($query);
        
        if (!$result) {
            throw new Exception("Invalid query.");
        }
        
        echo "<div class='query-results'><h3>Query Results</h3><pre>";
        while ($row = $result->fetch_assoc()) {
            print_r($row);
            echo "<br>";
        }
        echo "</pre></div>";
    } catch (Exception $e) {
        echo "<div class='error-message'>" . htmlspecialchars($e->getMessage()) . "</div>";
    }
    exit();
}

// Fetch Leaderboard
$query = "SELECT * FROM scores ORDER BY score DESC";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Arcade Dashboard</title>
    <link rel="stylesheet" type="text/css" href="assets/styles.css">
</head>
<body>
    <div class="container">
        <h1 class="arcade-title">🏆 Arcade Leaderboard 🏆</h1>

        <div class="leaderboard">
            <table>
                <tr>
                    <th>Player</th>
                    <th>Score</th>
                </tr>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['username']) ?></td>
                        <td><?= htmlspecialchars($row['score']) ?></td>
                    </tr>
                <?php endwhile; ?>
            </table>
        </div>

        <div class="sql-input">
            <h2>Can't find your score? Try check it out here!</h2>
            <form method="GET">
                <input type="text" name="query" placeholder="player name......">
                <button type="submit">Submit</button>
            </form>
        </div>
    </div>
</body>
</html>
