CREATE DATABASE IF NOT EXISTS ctf_db;
USE ctf_db;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(50) NOT NULL
);

INSERT INTO users (username, password) VALUES
('admin', 'password123'); 

CREATE TABLE scores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    score INT NOT NULL,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO scores (username, score) VALUES
('Naiad', 20000),
('Josept Desaulniers', 15000),
('707', 18000),
('Zelda', 13000),
('Aesop Carl', 22000),
('Admin',0),
('Norton Campbell',19000);

CREATE TABLE secrets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    directory VARCHAR(255) NOT NULL,
    fake_flag VARCHAR(255) NOT NULL,
    history  VARCHAR(255) NOT NULL,
    version   VARCHAR(255) NOT NULL
);

INSERT INTO secrets (directory, fake_flag, history,version) VALUES 
('/hidden_directory/exploit.php', 'ICTF25{try_harder}','edited on 3/16/2024 :05:14','3367892140');


