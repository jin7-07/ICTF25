from flask import Flask, jsonify, request, make_response, render_template_string, redirect, url_for
import jwt
import datetime
import os

app = Flask(__name__)

SECRET = "supersecret"
# ----------------------------
# Part 1 + 2: HTML Source + JWT Token as Cookie
# ----------------------------
@app.route("/")
def index():
    payload = {
        "user": "guest",
        "exp": datetime.datetime.utcnow() + datetime.timedelta(minutes=10),
        "flag2": "_c0m3s"
    }
    token = jwt.encode(payload, SECRET, algorithm="HS256")

    html = '''
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Welcome to Scavenger</title>
        <style>
            body {
                background: linear-gradient(135deg, #e0f7fa, #fce4ec);
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                text-align: center;
                padding: 50px;
                color: #333;
            }
            h1 {
                font-size: 2.5em;
                margin-bottom: 30px;
                color: #00796b;
            }
            button {
                background-color: #f06292;
                border: none;
                color: white;
                padding: 15px 30px;
                margin: 10px;
                border-radius: 8px;
                font-size: 1em;
                cursor: pointer;
                box-shadow: 0 4px 6px rgba(0,0,0,0.1);
                transition: all 0.2s ease-in-out;
            }
            button:hover {
                background-color: #ec407a;
                transform: scale(1.05);
            }
            .container {
                max-width: 600px;
                margin: auto;
                background: rgba(255, 255, 255, 0.8);
                border-radius: 15px;
                padding: 30px;
                box-shadow: 0 10px 25px rgba(0,0,0,0.1);
            }
            .note {
                font-style: italic;
                margin-top: 30px;
                color: #666;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Start your scavenger hunt! 🧩</h1>
            <!-- ICTF25{h3r3 -->
            <form action="/rickroll" method="get">
                <button type="submit">🎁 Click me for a surprise!</button>
            </form>
            <form action="/mirror" method="get">
                <button type="submit">💅 Check the Mirror</button>
            </form>
            <p class="note">Keep your eyes open, sometimes clues are hidden where you least expect them...</p>
            <p class="note">Did you had some cookies before joining ictf? It's nice!🍪</p>
        </div>
    </body>
    </html>
    '''

    resp = make_response(render_template_string(html))
    resp.set_cookie("token", token)
    return resp

# ----------------------------
# Rickroll Redirect
# ----------------------------
@app.route("/rickroll")
def rickroll():
    return redirect("https://www.youtube.com/watch?v=dQw4w9WgXcQ")

# ----------------------------
# Part 3: Exposed Config File
# ----------------------------
@app.route("/config.js")
def config_file():
    js = '''
    // config.js
    const CONFIG = {
        db: "localhost",
        api_key: "12345-ABCDE",
        timeout: 5000,
        // 🕵️ You might want to take a closer look...
        flag_3: "_fr0m"
    };
    '''
    response = make_response(js)
    response.headers['Content-Type'] = 'application/javascript'
    return response

#--------------------------
# Mirror Page ( Header Flag Clue)
# ----------------------------

@app.route("/mirror")
def mirror():
    html = '''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Vanity Mirror</title>
        <meta name="mirror-hint" content="Some reflections are hidden in plain sight.">
        <style>
            body {
                background: radial-gradient(circle at center, #fff5f8, #ffe6f0);
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                height: 100vh;
                margin: 0;
            }
            .mirror-frame {
                border: 8px solid #ffb6c1;
                border-radius: 50%;
                width: 300px;
                height: 300px;
                background: #ffffff;
                box-shadow: 0 0 25px rgba(255, 105, 180, 0.5);
                display: flex;
                align-items: center;
                justify-content: center;
                position: relative;
                margin-bottom: 30px;
            }
            .mirror-text {
                transform: scaleX(-1);
                font-size: 1.5em;
                color: #555;
                text-align: center;
                padding: 20px;
            }
            #clue {
                font-size: 1.2em;
                color: #444;
                margin-bottom: 15px;
            }
            .fake-flag {
                background: #ffe6f0;
                padding: 10px 20px;
                border-radius: 10px;
                font-weight: bold;
                color: #c71585;
                box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            }
        </style>
    </head>
    <body>
        <div class="mirror-frame">
            <div class="mirror-text">You look fabulous!</div>
        </div>
        <p id="clue"></p>
        <p class="fake-flag">ICTF25{almost_there_glam}</p>

        <script>
            // Typing effect
            const msg = "Not everything is visible — some things ride along silently.";
            let i = 0;
            function type() {
                if (i < msg.length) {
                    document.getElementById("clue").innerHTML += msg.charAt(i);
                    i++;
                    setTimeout(type, 45);
                }
            }
            type();

            console.log("Maybe try inspecting what’s riding with the response? 🕵️");
        </script>
    </body>
    </html>
    '''
    response = make_response(render_template_string(html))
    response.headers["X-Flag-Part4"] = "_th33333333333"
    return response

# ----------------------------
# Part 5: robots.txt
# ----------------------------
@app.route("/robots.txt")
def robots():
    content = '''
User-agent: *
Disallow: /admin
# Last piece: _saUc3}
    '''
    response = make_response(content)
    response.headers['Content-Type'] = 'text/plain'
    return response

# ----------------------------
# Fake Admin Panel for Misdirection + clue for flag 3
# ----------------------------
@app.route("/admin")
def admin_panel():
    html = '''
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Admin Panel</title>
        <style>
            body {
                margin: 0;
                overflow: hidden;
                background: black;
                color: #0f0;
                font-family: monospace;
            }
            h1 {
                position: absolute;
                top: 20%;
                width: 100%;
                text-align: center;
                font-size: 3em;
                color: #0f0;
                text-shadow: 0 0 10px #0f0;
                z-index: 1;
            }
            p {
                position: absolute;
                top: 35%;
                width: 100%;
                text-align: center;
                font-size: 1.2em;
                color: #0f0;
                z-index: 1;
            }
            .clues {
                position: absolute;
                bottom: 5%;
                width: 100%;
                text-align: center;
                font-size: 0.9em;
                color: #0f0;
                opacity: 0.7;
                z-index: 1;
            }
            canvas {
                position: absolute;
                top: 0;
                left: 0;
            }
        </style>
    </head>
    <body>
        <canvas id="matrix"></canvas>
        <h1>🛡️ Admin Login</h1>
        <p>Access Denied. This area is for elite eyes only.</p>

        <div class="clues">
            <!-- There's nothing to see here... or is there? -->
            <!-- Maybe try config files? -->
            <!-- I had some annoying setup issues with <code>python</code>, <code>javascript</code>, <code>html</code>, and <code>css</code> 😤 -->
        </div>

        <script>
            const canvas = document.getElementById('matrix');
            const ctx = canvas.getContext('2d');

            canvas.height = window.innerHeight;
            canvas.width = window.innerWidth;

            const chars = "ABCDEFGHIJアァイィウヴエカキクケコサシスセ01234ソタチツナニハヒフヘホマミムメモヤユヨラリルレロワンKLMNOPQRSTUVWXYZ56789";
            const fontSize = 14;
            const columns = canvas.width / fontSize;
            const drops = Array.from({ length: columns }).fill(1);

            function draw() {
                ctx.fillStyle = "rgba(0, 0, 0, 0.05)";
                ctx.fillRect(0, 0, canvas.width, canvas.height);

                ctx.fillStyle = "#0f0";
                ctx.font = fontSize + "px monospace";

                for (let i = 0; i < drops.length; i++) {
                    const text = chars.charAt(Math.floor(Math.random() * chars.length));
                    ctx.fillText(text, i * fontSize, drops[i] * fontSize);

                    if (drops[i] * fontSize > canvas.height && Math.random() > 0.975) {
                        drops[i] = 0;
                    }

                    drops[i]++;
                }
            }

            setInterval(draw, 35);
        </script>
    </body>
    </html>
    '''
    return render_template_string(html)


# ----------------------------
# Fake Flag Endpoint
# ----------------------------
@app.route("/flag.txt")
def fake_flag():
    return "ICTF{this_is_a_fake_flag}" 

# ----------------------------
# Run the app
# ----------------------------
if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
